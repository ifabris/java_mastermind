/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2_projekt;

import hr.algebra.mastermind.Mastermind;
import hr.algebra.reflection.utils.ReflectionUtils;
import hr.algebra.serialization.SaveData;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import hr.algebra.utilities.SerializationUtils;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ivan
 */
public class FXMLDocumentController implements Initializable {

    private static final String FILE_NAME = "MastermindSave.ser";
    @FXML
    private FlowPane pinPanel;
    @FXML
    private FlowPane currentGuessPanel;
    @FXML
    private VBox previousGuessPanel;
    @FXML
    private Button submitButton;
    @FXML
    private Button clearButton;

    private Mastermind mastermind;
    private int maxGuesses;
    private int brojKrugova;
    private Color[] poljeBoja;
    private char[] poljeSlova;
    private String currentGuessString;
    private List<String> allGuesses;

    public FXMLDocumentController() {
        poljeSlova = new char[]{'R', 'G', 'B', 'O', 'Y', 'P'};
        poljeBoja = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.YELLOW, Color.PURPLE};
        maxGuesses = 10;
        brojKrugova = 4;
        currentGuessString = "";
        mastermind = new Mastermind(maxGuesses, brojKrugova, poljeSlova);
        StringBuilder classInfo = new StringBuilder();
        StringBuilder readClassAndMembersInfo = new StringBuilder();      
        ReflectionUtils.readClassInfo(mastermind.getClass(), classInfo);
        ReflectionUtils.readClassAndMembersInfo(mastermind.getClass(), readClassAndMembersInfo);
        
        System.out.println(classInfo);
        System.out.println(readClassAndMembersInfo);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        for (int i = 0; i < poljeBoja.length; i++) {
            Rectangle rectangle = new Rectangle(40, 40);
            rectangle.setFill(poljeBoja[i]);
            rectangle.setOnMouseClicked(new BojaClickListener(poljeSlova[i]));
            pinPanel.getChildren().add(rectangle);
        }

        clearButton.setOnAction(event -> {
            reset();
        });

        submitButton.setOnAction(event -> {
            if (mastermind.getPotez() < maxGuesses && !mastermind.isKraj() && currentGuessString.length() == brojKrugova) {

                mastermind.takeTurn(currentGuessString.toCharArray());
                addPreviousGuess(currentGuessString, mastermind.getTocnaBoja(), mastermind.getTocnaPozicija());
                reset();
                winConditionCheck();
            } else {
                winConditionCheck();
            }
        });
        clearButton.setOnAction(event -> {
            reset();
        });
    }

    public void updateGuessPanel() {

        char[] guessLetters = currentGuessString.toCharArray();
        Circle[] pins = new Circle[guessLetters.length];
        for (int i = 0; i < guessLetters.length; i++) {
            for (int j = 0; j < poljeSlova.length; j++) {
                if (guessLetters[i] == poljeSlova[j]) {

                    pins[i] = new Circle();
                    pins[i].setRadius(10);
                    pins[i].setFill(poljeBoja[j]);
                    break;
                }
            }
        }
        currentGuessPanel.getChildren().clear();
        currentGuessPanel.getChildren().addAll(pins);
    }

    public void reset() {

        currentGuessString = "";
        updateGuessPanel();
    }

    class BojaClickListener implements EventHandler<MouseEvent> {

        private char letter;

        BojaClickListener(char letter) {
            this.letter = letter;
        }

        @Override
        public void handle(MouseEvent event) {

            if (currentGuessString.length() < brojKrugova) {
                currentGuessString += letter;
                updateGuessPanel();
            }
        }
    }

    public void addPreviousGuess(String guessString, int tocnaBoja, int tocnaPozicija) {
        Text correctString = new Text("B: " + tocnaBoja + " P: " + tocnaPozicija);
        char[] guessLetters = guessString.toCharArray();
        Circle[] krugovi = new Circle[guessLetters.length];
        for (int i = 0; i < guessLetters.length; i++) {
            for (int j = 0; j < poljeSlova.length; j++) {
                if (guessLetters[i] == poljeSlova[j]) {

                    krugovi[i] = new Circle();
                    krugovi[i].setRadius(15);
                    krugovi[i].setFill(poljeBoja[j]);
                    break;
                }
            }
        }
        FlowPane flow = new FlowPane();
        flow.setHgap(5);
        flow.setVgap(5);
        flow.getChildren().addAll(krugovi);
        flow.getChildren().add(correctString);
        previousGuessPanel.getChildren().add(flow);
    }

    public void winConditionCheck() {
        if (mastermind.getPotez() < maxGuesses) {
            if (mastermind.isKraj()) {
                displayMessage("Won");
            } else {
                displayMessage(maxGuesses - mastermind.getPotez() + " turn(s) left!");
            }
        } else {
            if (mastermind.isKraj()) {
                displayMessage("Won");
            } else {
                displayMessage("Lost");
            }
        }
    }

    public void displayMessage(String message) {

        Text text = new Text(message);
        previousGuessPanel.getChildren().add(text);
    }
    
    public void saveGame() throws IOException{
        int tocnaPozicija = mastermind.getTocnaPozicija();
        int tocnaBoja = mastermind.getTocnaBoja();
        int potez = mastermind.getPotez();
        char[] tocniKrugovi = mastermind.getTocniKrugovi();
        SaveData data = new SaveData(tocniKrugovi, potez, tocnaPozicija, tocnaBoja,allGuesses);
        try {
            SerializationUtils.write(data, FILE_NAME);
        } catch (IOException e) {
            System.out.println("Couldn't save : " + e.getMessage());
        }
        try {
            SaveData read = (SaveData) SerializationUtils.read(FILE_NAME);
            System.out.println(read);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
