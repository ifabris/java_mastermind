/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2_projekt_player2;


import hr.algbera.rmi.ChatClient;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

/**
 *
 * @author Ivan
 */
public class FXMLDocumentController implements Initializable {
    
    
    private final String TIME_FORMAT = "HH:mm:ss";
    private static final String MESSAGE_FORMAT = "%s (%s): %s";
    private final String CLIENT_NAME = "Client";
    private static final int MESSAGE_LENGTH = 78;
    private static final int FONT_SIZE = 15;
    
    private ObservableList<Node> messages;

    private ChatClient chatClient;

            public static final int PORT = 1989;
    public static final String HOST = "localhost";

    private final int brojKrugova = 4;
    private Color[] poljeBoja;
    private char[] poljeSlova;
    private static String currentGuessString = "";
    @FXML
    private FlowPane codePanel;
    @FXML
    private FlowPane sendCodePanel;
    @FXML
    private Button btnReset;
    @FXML
    private Button btnSend;
    @FXML
    private VBox vbMessages;
    @FXML
    private TextField tfMessage;
    
    @FXML
    private void send(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            sendMessage();
        }
    }

    @FXML
    private void sendMessage() {
        if (tfMessage.getText().trim().length() > 0) {
            chatClient.sendMessage(tfMessage.getText().trim());
            addMessage(tfMessage.getText().trim(), CLIENT_NAME, Color.BLACK);
            tfMessage.clear();
        }
    }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {

         chatClient = new ChatClient(this);
        messages = FXCollections.observableArrayList();
        Bindings.bindContentBidirectional(messages, vbMessages.getChildren());
        tfMessage.textProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue.length() >= MESSAGE_LENGTH) {
                        ((StringProperty) observable).setValue(oldValue);
                    }
                }
        );
        
    poljeSlova = new char[]{'R', 'G', 'B', 'O', 'Y', 'P'};
    poljeBoja = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.YELLOW, Color.PURPLE};
    
     for (int i = 0; i < poljeBoja.length; i++) {
            Rectangle rectangle = new Rectangle(40, 40);
            rectangle.setFill(poljeBoja[i]);
            rectangle.setOnMouseClicked(new BojaClickListener(poljeSlova[i]));
            codePanel.getChildren().add(rectangle);
        }
     
         btnReset.setOnAction(event -> {
            reset();
        });
         
         btnSend.setOnAction((ActionEvent event) -> {
          if (currentGuessString.length() == brojKrugova) {
                System.out.println(currentGuessString);
            try (Socket client = new Socket(HOST, PORT)) {
            System.err.println("Client is connecting to " + client.getInetAddress() + ":" + client.getPort());
            try {
                sendExternalizableRequest(client);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
            }
        });
    }
    public void postMessage(String message, String name, Color color) {
        Platform.runLater(() -> addMessage(message, name, color));
    }

    private void addMessage(String message, String name, Color color) {
        Label label = new Label();
        label.setFont(new Font(FONT_SIZE));
        label.setTextFill(color);
        label.setText(String.format(MESSAGE_FORMAT, LocalTime.now().format(DateTimeFormatter.ofPattern(TIME_FORMAT)), name, message));
        messages.add(label);
    }

    private static void sendExternalizableRequest(Socket client) throws IOException, ClassNotFoundException {
        ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
        oos.writeObject(currentGuessString);
        System.out.println("Bruno " +  ois.readObject());
    }

class BojaClickListener implements EventHandler<MouseEvent> {

        private char letter;

        BojaClickListener(char letter) {
            this.letter = letter;
        }    

        @Override
        public void handle(MouseEvent event) {
            if (currentGuessString.length() < brojKrugova) {
                currentGuessString += letter;
                updateGuessPanel();
            }
        }
    }

        public void updateGuessPanel() {

        char[] guessLetters = currentGuessString.toCharArray();
        Circle[] pins = new Circle[guessLetters.length];
        for (int i = 0; i < guessLetters.length; i++) {
            for (int j = 0; j < poljeSlova.length; j++) {
                if (guessLetters[i] == poljeSlova[j]) {

                    pins[i] = new Circle();
                    pins[i].setRadius(10);
                    pins[i].setFill(poljeBoja[j]);
                    break;
                }
            }
        }
        sendCodePanel.getChildren().clear();
        sendCodePanel.getChildren().addAll(pins);         
    }

        public void reset() {

        currentGuessString = "";
        updateGuessPanel();
    }
}
