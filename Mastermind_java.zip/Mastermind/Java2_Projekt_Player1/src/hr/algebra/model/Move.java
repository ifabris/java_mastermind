/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Ivan
 */
public class Move implements Serializable{
    
    private static final long serialVersionUID = 2L;
    
    private char[] tocniKrugovi;
    private int potez;
    private int tocnaPozicija;

    private int tocnaBoja;
    private String currentGuesses; 

    public Move(char[] tocniKrugovi, int potez, int tocnaPozicija, int tocnaBoja, String currentGuesses) {
        this.tocniKrugovi = tocniKrugovi;
        this.potez = potez;
        this.tocnaPozicija = tocnaPozicija;
        this.tocnaBoja = tocnaBoja;
        this.currentGuesses = currentGuesses;
    }

    public char[] getTocniKrugovi() {
        return tocniKrugovi;
    }

    public void setTocniKrugovi(char[] tocniKrugovi) {
        this.tocniKrugovi = tocniKrugovi;
    }

    public int getPotez() {
        return potez;
    }

    public void setPotez(int potez) {
        this.potez = potez;
    }

    public int getTocnaPozicija() {
        return tocnaPozicija;
    }

    public void setTocnaPozicija(int tocnaPozicija) {
        this.tocnaPozicija = tocnaPozicija;
    }

    public int getTocnaBoja() {
        return tocnaBoja;
    }

    public void setTocnaBoja(int tocnaBoja) {
        this.tocnaBoja = tocnaBoja;
    }

    public String getCurrentGuesses() {
        return currentGuesses;
    }

    public void setCurrentGuesses(String currentGuesses) {
        this.currentGuesses = currentGuesses;
    }

    @Override
    public String toString() {
        return "Move{" + "tocniKrugovi=" + tocniKrugovi + ", potez=" + potez + ", tocnaPozicija=" + tocnaPozicija + ", tocnaBoja=" + tocnaBoja + ", currentGuesses=" + currentGuesses + '}';
    }
    
    
}
