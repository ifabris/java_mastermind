/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.mastermind;

import java.util.ArrayList;

/**
 *
 * @author Ivan
 */
public class Mastermind {

    final private char[] bojeSlovima;
    final private int maxPotezi;
    final private int brojKrugova;

    private char[] tocniKrugovi;
    private int potez = 0;
    private int tocnaPozicija = 0;
    private int tocnaBoja = 0;
    private boolean kraj = false;


    public Mastermind(int maxTurns, int brojKrugova, char[] bojeSlovima, char[] code) {
        this.maxPotezi = maxTurns;
        this.brojKrugova = brojKrugova;
        this.bojeSlovima = bojeSlovima;
        System.out.println("Kod : " + code);
        tocniKrugovi=code;
        System.out.println(tocniKrugovi);
    }

    public void takeTurn(char[] guess) {

        tocnaPozicija = brojTocnihPozicija(guess);
        tocnaBoja = brojTocnihBoja(guess);
        potez++;

        if (tocnaPozicija == brojKrugova) {
            kraj = true;
        }
    }

    int brojTocnihPozicija(char[] guess) {
        int brojac = 0;
        if (tocniKrugovi == null) {
            System.out.println("Ubi se");
        }
        for (int i = 0; i < tocniKrugovi.length; i++) {
            if (tocniKrugovi[i] == guess[i]) {
                brojac++;
            }
        }

        return brojac;
    }

    int brojTocnihBoja(char[] guess) {
        
        int counter = 0;

        ArrayList<Character> colors = new ArrayList<>(bojeSlovima.length);
        for (int i = 0; i < guess.length; i++) {
            colors.add(tocniKrugovi[i]);
        }
        for (int i = 0; i < guess.length; i++) {
            for (int j = 0; j < colors.size(); j++) {
                if (guess[i] == colors.get(j)) {
                    counter++;
                    colors.remove(j);
                    break;
                }
            }
        }
        return counter;
    }

    public char[] getBoje() {
        return bojeSlovima;
    }

    public int getMaxPotezi() {
        return maxPotezi;
    }

    public int getBrojKrugova() {
        return brojKrugova;
    }

    public char[] getTocniKrugovi() {
        return tocniKrugovi;
    }

    public int getPotez() {
        return potez;
    }

    public int getTocnaPozicija() {
        return tocnaPozicija;
    }

    public int getTocnaBoja() {
        return tocnaBoja;
    }

    public boolean isKraj() {
        return kraj;
    }
}
