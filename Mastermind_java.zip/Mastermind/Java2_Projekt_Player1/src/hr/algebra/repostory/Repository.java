/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.repostory;

import hr.algebra.model.Move;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Ivan
 */
public class Repository implements Serializable  {
    
     private static final long serialVersionUID = 3L;
    
    // eager singleton    
    private Repository() {        
    }
    
    private static final Repository INSTANCE = new Repository();

    public static Repository getInstance() {
        return INSTANCE;
    }
    
    private final ObservableList<Move> moves = FXCollections.observableArrayList();

    public ObservableList<Move> getMoves() {
        return moves;
    }
    public void addMove(Move move) {
        moves.add(move);
    }
    
     private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.writeObject(new ArrayList<>(moves));
    }

    // we must imitate constructor, so we create lists manually
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        List<Move> serializedMoves = (List<Move>) ois.readObject();
        INSTANCE.moves.clear();
        INSTANCE.moves.addAll(serializedMoves);     
    }
       
    // Repository must be a TRUE Singleton so we must secure 
    // that the instance created by deserialization is discarded 
    private Object readResolve() {
        // Return the one true Repository and let the garbage collector
        // take care of the Repository impersonator.
        return INSTANCE;
    }
    
        public void swapMoves(ObservableList<Move> moves) {
        this.moves.clear();
        this.moves.addAll(moves);
    }

}
