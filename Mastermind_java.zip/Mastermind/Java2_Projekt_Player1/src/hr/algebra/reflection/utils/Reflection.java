/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.reflection.utils;

import java2_projekt.FXMLDocumentController;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author Korisnik
 */
public class Reflection {

    private static final String PACKAGE_NAME = "hr.algebra.model.";
    private static final String PACKAGE_LOCATION
            = "C:\\Users\\Ivan\\Desktop\\Faks\\JAVA2_SAFENETWORKWORKING\\src\\hr\\algebra\\model";

    public static void saveToHTML() {
        try (FileWriter docuGenerator
                = new FileWriter("documentation.html")) {
            docuGenerator.write("<!DOCTYPE html>");
            docuGenerator.write("<html>");
            docuGenerator.write("<head>");
            docuGenerator.write("<title>Class documentation</title>");
            docuGenerator.write("</head>");
            docuGenerator.write("<link rel=\"stylesheet\" "
                    + "href=\"documentation.css\">");

            docuGenerator.write("<body>");

            List<String> filesInPackage = Files
                    .list(Paths.get(PACKAGE_LOCATION))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());

            for (String fileName : filesInPackage) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject = Class.forName(PACKAGE_NAME + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject.getName()
                        + " </h1>");

                java.lang.reflect.Field[] fields = unknownObject
                        .getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");
                docuGenerator.write("<p>");

                for (java.lang.reflect.Field field : fields) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }
                docuGenerator.write("</p>");
                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors = unknownObject.getConstructors();

                for (Constructor con : constructors) {
                    Parameter[] params = con.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h2>Constructor parameters: </h2>");
                        docuGenerator.write("<p>");
                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h2>Default constructor without parameters"
                                + "</h2>");
                    }
                }

                docuGenerator.write("<h1>Method name: " + unknownObject.getName()
                        + " </h1>");

                docuGenerator.write("<h2>Methods:</h2>");
                docuGenerator.write("<p>");

                for (java.lang.reflect.Field field : fields) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }
                docuGenerator.write("</p>");
                docuGenerator.write("<h2>Methods:</h2>");

                Method[] methods = unknownObject.getMethods();

                for (Method method : methods) {
                    Parameter[] params = method.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h2>Method parameters: </h2>");
                        docuGenerator.write("<p>");
                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h2>Method without parameters"
                                + "</h2>");
                    }
                }

            }

            docuGenerator.write("</p>");
            docuGenerator.write("</body>");
            docuGenerator.write("</html>");

            docuGenerator.flush();

            System.out.println("Documentation successfuly done!");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(
                    Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(
                    Level.SEVERE, null, ex);
        }
    }
}
