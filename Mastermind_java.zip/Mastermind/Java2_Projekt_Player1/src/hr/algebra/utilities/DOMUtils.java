/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.utilities;

import hr.algebra.model.Move;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

/**
 *
 * @author Korisnik
 */
public class DOMUtils {

    private static final String REPLAY_PATH = "replay.xml";
    private static final String SAVE_GAME_PATH = "saveGameDOM.xml";

    private static final String REPLAY = "replay";
    private static final String MOVE = "move";
    private static final String TOCNI_KRUGOVI = "tocniKrugovi";
    private static final String POTEZ = "potez";
    private static final String TOCNA_POZICIJA = "tocnaPozicija";
    private static final String TOCNA_BOJA = "tocnaBoja";
    private static final String CURRENT_GUESS = "currentGuess";
    private static String fromCharArray;


    public static void saveReplay(ObservableList<Move> moves) {

        try {
            Document document = createDocument(REPLAY);
            moves.forEach(m -> document.getDocumentElement().appendChild(createMoveElement(m, document)));
            saveDocument(document, REPLAY_PATH);
        } catch (ParserConfigurationException | TransformerException e) {
            Logger.getLogger(DOMUtils.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    private static Element createMoveElement(Move move, Document document) throws DOMException {
        fromCharArray = new String(move.getTocniKrugovi());
        Element element = document.createElement(MOVE);
        element.setAttributeNode(createAttribute(document, POTEZ, Integer.toString(move.getPotez())));
        element.appendChild(createElement(document, TOCNI_KRUGOVI, fromCharArray));
        element.appendChild(createElement(document, TOCNA_POZICIJA, Integer.toString(move.getTocnaPozicija())));
        element.appendChild(createElement(document, TOCNA_BOJA, Integer.toString(move.getTocnaBoja())));
        element.appendChild(createElement(document, CURRENT_GUESS, move.getCurrentGuesses()));
        return element;
    }

    private static Document createDocument(String root) throws ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        DOMImplementation domImplementation = builder.getDOMImplementation();
        return domImplementation.createDocument(null, root, null);
    }

    private static Attr createAttribute(Document document, String name, String value) {
        Attr attr = document.createAttribute(name);
        attr.setValue(value);
        return attr;
    }

    private static Node createElement(Document document, String tagName, String data) {
        Element element = document.createElement(tagName);
        Text text = document.createTextNode(data);
        element.appendChild(text);
        return element;
    }

    private static void saveDocument(Document document, String fileName) throws TransformerException {
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        //transformer.transform(new DOMSource(document), new StreamResult(System.out));
        transformer.transform(new DOMSource(document), new StreamResult(new File(fileName)));
    }}

//    public static ObservableList<Move> loadReplay() throws TransformerConfigurationException {
//        ObservableList<Move> moves = FXCollections.observableArrayList();
//        try {
//            Document document = createDocument(new File(REPLAY_PATH));
//            NodeList nodes = document.getElementsByTagName(MOVE);
//            for (int i = 0; i < nodes.getLength(); i++) {
//                // dangerous class cast exception
//                moves.add(processMoveNode((Element) nodes.item(i)));
//            }
//
//        } catch (ParserConfigurationException | IOException | SAXException e) {
//            Logger.getLogger(DOMUtils.class.getName()).log(Level.SEVERE, null, e);
//        }
//        return moves;
//    }

//    private static Document createDocument(File file) throws SAXException, ParserConfigurationException, IOException {
//        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder builder = factory.newDocumentBuilder();
//        Document document = builder.parse(file);
//        return document;
//    }

 //   private static Move processMoveNode(Element element) throws TransformerConfigurationException {
//        StringWriter buf = new StringWriter();
//        Transformer xform = TransformerFactory.newInstance().newTransformer();
//        xform.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes"); // optional
//        xform.setOutputProperty(OutputKeys.INDENT, "yes"); // optional
//        xform.transform(element.getElementsByTagName(TOCNI_KRUGOVI), new StreamResult(buf));
//        try {
//            return new Move(
//                    element.getElementsByTagName(TOCNI_KRUGOVI),
//                    Integer.parseInt(element.getAttribute(POTEZ)),
//                    Integer.parseInt(element.getElementsByTagName(TOCNA_POZICIJA).item(0).getTextContent()),
//                    Integer.parseInt(element.getElementsByTagName(TOCNA_BOJA).item(0).getTextContent()),
//                    (element.getElementsByTagName(CURRENT_GUESS)
//            ));
//        } catch (DOMException dOMException) { 
//       }
//        return null; 
   //}
//}
