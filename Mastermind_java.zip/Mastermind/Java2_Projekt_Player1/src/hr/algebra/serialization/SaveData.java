/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.serialization;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Ivan
 */
public class SaveData implements Serializable{
    private static final long serialVersionUID = 2L;
    
    private char[] tocniKrugovi;
    private int potez;
    private int tocnaPozicija;

    private int tocnaBoja;
    private List<String> allGuesses;

    public SaveData(char[] tocniKrugovi, int potez, int tocnaPozicija, int tocnaBoja, List<String> allGuesses) {
        this.tocniKrugovi = tocniKrugovi;
        this.potez = potez;
        this.tocnaPozicija = tocnaPozicija;
        this.tocnaBoja = tocnaBoja;
        this.allGuesses = allGuesses;
    }

    @Override
    public String toString() {
        return "Tocni krugovi="+ tocniKrugovi[0]+""+tocniKrugovi[1]+""+tocniKrugovi[2]+""+tocniKrugovi[3]+"\n"
                + "Potez="+ potez +"\n"
                + "Tocna pozicija="+ tocnaPozicija+"\n"
                + "Tocna boja="+ tocnaBoja +"\n"
                + "Svi pokusaji="+ allGuesses;
    }

    public SaveData() {
    }

    public char[] getTocniKrugovi() {
        return tocniKrugovi;
    }

    public void setTocniKrugovi(char[] tocniKrugovi) {
        this.tocniKrugovi = tocniKrugovi;
    }

    public int getPotez() {
        return potez;
    }

    public void setPotez(int potez) {
        this.potez = potez;
    }

    public int getTocnaPozicija() {
        return tocnaPozicija;
    }

    public void setTocnaPozicija(int tocnaPozicija) {
        this.tocnaPozicija = tocnaPozicija;
    }

    public int getTocnaBoja() {
        return tocnaBoja;
    }

    public void setTocnaBoja(int tocnaBoja) {
        this.tocnaBoja = tocnaBoja;
    }
    
     
}
