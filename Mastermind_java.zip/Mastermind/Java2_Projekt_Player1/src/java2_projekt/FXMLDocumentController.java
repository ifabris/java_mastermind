/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2_projekt;

import hr.algebra.mastermind.Mastermind;
import hr.algebra.model.Move;
import hr.algebra.reflection.utils.Reflection;
import hr.algebra.reflection.utils.ReflectionUtils;
import hr.algebra.repostory.Repository;
import hr.algebra.rmi.ChatServer;
import hr.algebra.serialization.SaveData;
import hr.algebra.utilities.DOMUtils;
import hr.algebra.utilities.FileUtils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import hr.algebra.utilities.SerializationUtils;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Font;

/**
 *
 * @author Ivan
 */
public class FXMLDocumentController implements Initializable {



    private final String TIME_FORMAT = "HH:mm:ss";
    private static final String MESSAGE_FORMAT = "%s (%s): %s";
    private static final String SERVER_NAME = "Server";
    private static final int MESSAGE_LENGTH = 78;
    private static final int FONT_SIZE = 15;
    public static final int PORT = 1989;
    public static final String HOST = "localhost";
     private ObservableList<Node> messages;
    private  ChatServer chatServer;   
     
    private static final String FILE_NAME = "MastermindSave.ser";
    @FXML
    private FlowPane pinPanel;
    @FXML
    private FlowPane currentGuessPanel;
    @FXML
    private VBox previousGuessPanel;
    @FXML
    private Button submitButton;
    @FXML
    private Button clearButton;
    @FXML
    private VBox chatBox;
    @FXML
    private TextField textField;
    
    private Mastermind mastermind;
    private int maxGuesses;
    private int brojKrugova;
    private Color[] poljeBoja;
    private char[] poljeSlova;
    private String currentGuessString;
    private List<String> allGuesses = new ArrayList<>();
    public static char[] codeString;
    private static boolean exit = false;
    private int pozicija=0;
    private List<Move> moves = new ArrayList<>();
    private Move move;
    private int i = 0;
    
        private  void chat() {
       chatServer = new ChatServer(this);       
    }
    public FXMLDocumentController() throws InterruptedException {
        chat();
        acceptRequests();
        poljeSlova = new char[]{'R', 'G', 'B', 'O', 'Y', 'P'};
        poljeBoja = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.YELLOW, Color.PURPLE};
        maxGuesses = 10;
        brojKrugova = 4;
        currentGuessString = "";
        mastermind = new Mastermind(maxGuesses, brojKrugova, poljeSlova, codeString);
        StringBuilder classInfo = new StringBuilder();
        StringBuilder readClassAndMembersInfo = new StringBuilder();      
        ReflectionUtils.readClassInfo(mastermind.getClass(), classInfo);
        ReflectionUtils.readClassAndMembersInfo(mastermind.getClass(), readClassAndMembersInfo);
        
        System.out.println(classInfo);
        System.out.println(readClassAndMembersInfo);
    }
    
     private static void acceptRequests() throws InterruptedException {
     try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.err.println("Server listening on port: " + serverSocket.getLocalPort());           
            while (!exit) {
                Socket clientSocket = serverSocket.accept();
                System.err.println("Client connected from: " + clientSocket.getPort());               
                new Thread(() -> processExternalizableClient(clientSocket)).start();      
                Thread.sleep(500);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
     }
     


    
    private static void processExternalizableClient(Socket clientSocket) {
        try (ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());) {
            String code = (String) ois.readObject();
            System.out.println("Code is " + code);
            codeString = code.toCharArray();
            System.out.println(codeString);
            oos.writeObject(code); 
            exit = true;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        for (int i = 0; i < poljeBoja.length; i++) {
            Rectangle rectangle = new Rectangle(40, 40);
            rectangle.setFill(poljeBoja[i]);
            rectangle.setOnMouseClicked(new BojaClickListener(poljeSlova[i]));
            pinPanel.getChildren().add(rectangle);
        }
        
        clearButton.setOnAction(event -> {
            reset();
        });
             messages = FXCollections.observableArrayList();
        // manipulation on messages list reflects immediately on vbMessages
        Bindings.bindContentBidirectional(messages, chatBox.getChildren());
        // make sure text is not longer then message length
        textField.textProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue.length() >= MESSAGE_LENGTH) {
                        ((StringProperty) observable).setValue(oldValue);
                    }
                }
        );

        submitButton.setOnAction(event -> {
            turnTake();
            move = new Move(mastermind.getTocniKrugovi(),mastermind.getPotez(),mastermind.getTocnaBoja(),mastermind.getTocnaPozicija(), allGuesses.get(i));
            moves.add(move);
            Repository.getInstance().addMove(move);
            i++;
        });
  
    }

    private void turnTake() {
        if (mastermind.getPotez() < maxGuesses && !mastermind.isKraj() && currentGuessString.length() == brojKrugova) {
            
            mastermind.takeTurn(currentGuessString.toCharArray());
            addPreviousGuess(currentGuessString, mastermind.getTocnaBoja(), mastermind.getTocnaPozicija());

            System.out.println(move);
            reset();
            winConditionCheck();
        } else {
            winConditionCheck();
        }
    }
    private void addMessage(String message, String name, Color color) {
        Label label = new Label();
        label.setFont(new Font(FONT_SIZE));
        label.setTextFill(color);
        label.setText(String.format(MESSAGE_FORMAT, LocalTime.now().format(DateTimeFormatter.ofPattern(TIME_FORMAT)), name, message));
        messages.add(label);
    }
     public void postMessage(String message, String name, Color color) {
        Platform.runLater(() -> addMessage(message, name, color));
    }
     @FXML
    private void send(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            sendMessage();
        }
    }
    
    @FXML
    private void sendMessage() {
        if (textField.getText().trim().length() > 0) {
            chatServer.sendMessage(textField.getText().trim());
            addMessage(textField.getText().trim(), SERVER_NAME, Color.BLACK);
            textField.clear();
        }
    }

    public void updateGuessPanel() {

        char[] guessLetters = currentGuessString.toCharArray();
        Circle[] pins = new Circle[guessLetters.length];
        for (int i = 0; i < guessLetters.length; i++) {
            for (int j = 0; j < poljeSlova.length; j++) {
                if (guessLetters[i] == poljeSlova[j]) {

                    pins[i] = new Circle();
                    pins[i].setRadius(10);
                    pins[i].setFill(poljeBoja[j]);
                    break;
                }
            }
        }
        currentGuessPanel.getChildren().clear();
        currentGuessPanel.getChildren().addAll(pins);
    }

    public void reset() {

        currentGuessString = "";
        updateGuessPanel();
    }

    class BojaClickListener implements EventHandler<MouseEvent> {

        private char letter;

        BojaClickListener(char letter) {
            this.letter = letter;
        }

        @Override
        public void handle(MouseEvent event) {

            if (currentGuessString.length() < brojKrugova) {
                currentGuessString += letter;
                updateGuessPanel();
            }
        }
    }

    public void addPreviousGuess(String guessString, int tocnaBoja, int tocnaPozicija) {
        Text correctString = new Text("B: " + tocnaBoja + " P: " + tocnaPozicija);
        allGuesses.add(guessString);
        pozicija++;
        char[] guessLetters = guessString.toCharArray();
        Circle[] krugovi = new Circle[guessLetters.length];
        for (int i = 0; i < guessLetters.length; i++) {
            for (int j = 0; j < poljeSlova.length; j++) {
                if (guessLetters[i] == poljeSlova[j]) {

                    krugovi[i] = new Circle();
                    krugovi[i].setRadius(15);
                    krugovi[i].setFill(poljeBoja[j]);
                    break;
                }
            }
        }
        FlowPane flow = new FlowPane();
        flow.setHgap(5);
        flow.setVgap(5);
        flow.getChildren().addAll(krugovi);
        flow.getChildren().add(correctString);
        previousGuessPanel.getChildren().add(flow);
    }

    public void winConditionCheck() {
        if (mastermind.getPotez() < maxGuesses) {
            if (mastermind.isKraj()) {
                displayMessage("Won");
                for (Move m : moves) {
                    displayMessage(m.toString());
                }
            } else {
                displayMessage(maxGuesses - mastermind.getPotez() + " turn(s) left!");
            }
        } else {
            if (mastermind.isKraj()) {
                displayMessage("Won");
            } else {
                displayMessage("Lost");
            }
        }
    }

    public void displayMessage(String message) {

        Text text = new Text(message);
        previousGuessPanel.getChildren().add(text);
    }
    
    public void saveGame() throws IOException{
        int tocnaPozicija = mastermind.getTocnaPozicija();
        int tocnaBoja = mastermind.getTocnaBoja();
        int potez = mastermind.getPotez();
        char[] tocniKrugovi = mastermind.getTocniKrugovi();
        SaveData data = new SaveData(tocniKrugovi, potez, tocnaPozicija, tocnaBoja,allGuesses);
        try {
            SerializationUtils.write(data.toString(), FILE_NAME);
        } catch (IOException e) {
            System.out.println("Couldn't save : " + e.getMessage());
        }
//        try {
//            SaveData read = (SaveData) SerializationUtils.read(FILE_NAME);
//            System.out.println(read);
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
    
    @FXML
    private void serialize() {
        try {
            File file = FileUtils.saveFileDialog(submitButton.getScene().getWindow(),"ser");
            if (file != null) {
                SerializationUtils.write(Repository.getInstance(), file.getAbsolutePath());
                alert("Mastermind", "Serialize", "Game saved");
            }
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void deserialize() {
        File file = FileUtils.uploadFileDialog(submitButton.getScene().getWindow(), "ser");
        if (file != null) {
            try {
                SerializationUtils.read(file.getAbsolutePath());
                List<Move> movesLoaded = new ArrayList<>();
                movesLoaded = Repository.getInstance().getMoves();
                mastermind = new Mastermind(maxGuesses, brojKrugova, poljeSlova, movesLoaded.get(0).getTocniKrugovi());
                for (Move move : movesLoaded) {
                    currentGuessString=move.getCurrentGuesses();
                    turnTake();
                }
                alert("Mastermind", "Serialize", "Game loaded");
            } catch (IOException | ClassNotFoundException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private void alert(String title, String contentText, String headerText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(contentText);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
    @FXML
    private void doReflection() {
        Reflection.saveToHTML();
    }
    
    @FXML
    private void saveDOM() {
        DOMUtils.saveReplay(Repository.getInstance().getMoves());
        alert("DOM", "XML documents saved", "Saved with no failures");
    }

}
